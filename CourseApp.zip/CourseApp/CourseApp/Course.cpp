#include "Course.h"
#include <cstdlib>



Course::Course() {
	preReqSize = 0;
	courseNum = -1;
}

int Course::getSize() {
	return preReqSize;
}

string Course::getTitle() {
	return title;
}

int Course::getCourseNum() {
	return courseNum;
}

void Course::setTitle(string title) {
	this->title = title;
}

void Course::setCourseNum(string courseNum) {
	int tmp = atoi(courseNum.substr(4, 3).c_str());
	this->courseNum = tmp;
}

void Course::setSize(int size) {
	this->preReqSize = size;
}