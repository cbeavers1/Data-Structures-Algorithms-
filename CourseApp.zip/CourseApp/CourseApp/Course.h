#include <string>
#include <vector>

using namespace std;

class Course {
private:
	int preReqSize;
	string title;
	int courseNum = 000;

public:
	Course();
	void setSize(int size);
	int getSize();
	void setCourseNum(string courseNum);
	int getCourseNum();
	void setTitle(string title);
	string getTitle();
	vector<Course> preReqs;

};

