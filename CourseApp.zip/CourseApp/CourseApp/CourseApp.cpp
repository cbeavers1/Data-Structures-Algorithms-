/*
* ==================================================================================================
Name: Charles Beavers
Course: CS-300
Project 2
=====================================================================================================
*/
#include <iostream>
#include <fstream>
#include <vector>
#include "Course.h"
#include <cstring>
#include <cstdlib> int atoi( const char *str );

using namespace std;

struct Node {
	Course course;
	Node* left;
	Node* right;

	// default constructor
	Node() {
		left = nullptr;
		right = nullptr;
	}

	// initialize with a bid
	Node(Course acourse) :
		Node() {
		course = acourse;
	}
};

//========================================================
//========================================================

// Create class for tree structure;
//
//========================================================
//========================================================

class BST {

private:
	Node* root;

	void addNode(Node* node, Course course);

public:
	BST();
	void PrintCourseList(Node* node);
	void Insert(Course course);
	Course Search(int courseNum);
	void Schedule();
	void Print();
	
};
// ====================
// Funciton Definitions
// ====================

BST::BST() {
	root = nullptr;
}

void BST::addNode(Node* node, Course course) {
	if (node == nullptr) {
		node = new Node(course);
		this->root = node;
	}
	else if (node->course.getCourseNum() < course.getCourseNum()) {
		// If left node is empty insert here
		if (node->left == nullptr) {
			node->left = new Node(course);
		} // Otherwise recurse left
		else {
			addNode(node->left, course);
		}
	} // Otherwise go right
	else {
		// If right node is empty insert here
		if (node->right == nullptr) {
			node->right = new Node(course);
		} // Otherwise recurse right
		else {
			addNode(node->right, course);
		}
	}
}

// Print each element in order 
void BST::PrintCourseList(Node* node) {

	if (node != nullptr) {
		// Traverse right
		PrintCourseList(node->right);

		// Print bid
		cout << node->course.getTitle() << " : " << node->course.getCourseNum() << endl;


		// Traverse left
		PrintCourseList(node->left);
	}
}

// Function used to initialize PrintCourseList with root
void BST::Schedule() {
	PrintCourseList(root);
}

// Function used to intitialize addNode function with root and course passed
void BST::Insert(Course course) {
	addNode(root, course);
}

// Function to return specific course mainly for printing info
Course BST::Search(int courseNum) {
	Node* currNode = root;

	while (currNode != nullptr) {

		// Match found
		if (currNode->course.getCourseNum() == courseNum) {
			return currNode->course;
		}
		else { // Move down tree until found or null
			if (courseNum > currNode->course.getCourseNum()) {
				currNode = currNode->left;
			}
			else {
				currNode = currNode->right;
			}
		}

	}

	Course course;
	return course;
}
//===================================================================
//===================================================================


void displayMenu() {
	cout << "----------------------" << endl;
	cout << "----------------------" << endl;
	cout << "Menu" << endl;
	cout << "1. Load Courses" << endl;
	cout << "2. Print Course List" << endl;
	cout << "3. Print Course" << endl;
	cout << "9. Exit" << endl;
	cout << "----------------------" << endl;
	cout << "----------------------" << endl;
}

void loadCourses(string filePath, BST& bst) {
	fstream infs;

	infs.open(filePath);

	if (!infs.is_open()) {
		cout << "File not found" << endl;
		return;
	}

	while (!infs.eof()) {
		vector<string> tmpCourse;
		string line;
		string temp;
		string t;
		char delim = ',';

		getline(infs, line);

		for (unsigned int i = 0; i < line.size(); ++i) {

			// Checking each character for delimitter 
			// Adding line information to vector
			if (line[i] == ',' || i == line.size() - 1) {
				if (i == line.size() - 1) {
					t = line[i];
					temp.append(t);
				}
				tmpCourse.push_back(temp);
				temp.clear();
			}
			else {
				t = line[i];
				temp.append(t);
			}

		}

		// Checking for format error
		if (tmpCourse.size() < 2) {
			cout << "Format error" << endl;
			return;
		}

		// Initialize course with segments of vector from file
		int tmpSize = tmpCourse.size() - 2;
		Course course;
		course.setCourseNum(tmpCourse[0]);
		course.setTitle(tmpCourse[1]);
		
		for (int i = 2; i < tmpCourse.size(); ++i) {
			Course course2;
			course2.setCourseNum(tmpCourse[i]);

			course.preReqs.push_back(course2);
		}

		// Insert course into tree
		bst.Insert(course);



	}
	

}

int main() {

	// Initialize variables
	BST* courseList; 
	courseList = new BST();

	int choice = 0;
	vector<Course> courses;
	string filePath = "courses.txt";


	// Exit condition
	while (choice != 9) {
		displayMenu();
		
		cin >> choice;

		switch (choice) {

			case 1:
				loadCourses(filePath, *courseList);
				system("cls");
				break;

			case 2:
				cout << "=========================" << endl;
				cout << "SAMPLE SCHEDULE" << endl;
				cout << "=========================" << endl;
				courseList->Schedule();
				cout << "-------------------------" << endl;
				system("pause");
				system("cls");
				break;

			case 3:
				int num;

				cout << "Enter course number: " << endl;
				cin >> num;

				cout << courseList->Search(num).getTitle() << " : " << courseList->Search(num).getCourseNum() << endl;
				system("pause");
				system("cls");

				break;

			case 9:
				cout << "Goodbye" << endl;
				exit(0);

			default:
				// Error handling section
				cout << "Invalid. Try again." << endl;
				system("cls");
		}
	}
}